
const initialState = {
    value : '',

}

export default function(state = initialState,action){
    switch(action.type){
        case "REVIEW_SUBMIT_SUCCESS":
            return {
                ...state,
                value : action.payload
            }
        default:
    }
    return state;
}