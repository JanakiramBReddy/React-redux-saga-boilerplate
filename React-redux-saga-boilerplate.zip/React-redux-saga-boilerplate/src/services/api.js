import axios from "axios";

export function createUser(userData){
    return axios.post('https://reqres.in/api/users')
}

export function getAllUsers(){
    return axios.get('https://reqres.in/api/users')
}