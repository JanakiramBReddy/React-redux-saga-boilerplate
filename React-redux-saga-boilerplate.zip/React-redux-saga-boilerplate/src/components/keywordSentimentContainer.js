import React from 'react';
import { connect } from 'react-redux';
import {withStyles} from '@material-ui/core';

const style = theme => ({
    keywordSentimentBox:{
        display:'flex',
        alignItems: 'center',
        justifyContent: 'center',
        height:'375px'
    },
    LabelStyle:{
        fontFamily:'Raleway, Arial'
    },
    displayWordBox:{
        border:'1px solid rgba(158, 122, 112, 0.48)',
        height:'180px',
        width:'300px',
        margin:'20px'
    }
})

function keywordSentimentContainer(props) {
    const {classes} = props;

  return (
        <div className={classes.keywordSentimentBox}>
           <span><label className={classes.LabelStyle}>Keywords</label></span>
           <div className={classes.displayWordBox}>
               <ul>
                    {props.reviewResult.map((item,i) => (
                        <li key={item.id}>{item.email}</li>
                    ))}
                </ul>
           </div>
           <span><label className={classes.LabelStyle}>Sentiments</label></span>
           <div className={classes.displayWordBox}>
                <ul>
                    {props.reviewResult.map((item,i) => (
                        <li key={item.id}>{item.first_name}</li>
                    ))}
               </ul>
           </div>
        </div>
  );
}


function mapStateToProps(state){
    return {
        reviewResult : state.review.value
    }
}

export default connect(mapStateToProps)(withStyles(style)(keywordSentimentContainer))
