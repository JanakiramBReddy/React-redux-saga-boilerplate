import React from 'react';
import Grid from '@material-ui/core/Grid';
import ReviewContainer from './components/reviewContainer';
import KeywordSentimentContainer from './components/keywordSentimentContainer';

function App() {
  return (
    <div className="App" style={{backgroundColor:'rgb(245, 240, 240)',height:660}}>
      <Grid container>
          <Grid item xs={12}>
              <ReviewContainer />
              <KeywordSentimentContainer />
          </Grid>
      </Grid>
    </div>
  );
}

export default App;
