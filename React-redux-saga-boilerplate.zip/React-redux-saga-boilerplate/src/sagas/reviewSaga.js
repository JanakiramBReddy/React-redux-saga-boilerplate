import {call,all,put,takeLatest} from 'redux-saga/effects';
import {createUser,getAllUsers} from '../services/api';
import {reviewActions} from '../constants/actionTypes';

export function* reviewSubmit(args){
    let userData = {
        "name": args.payload.text,
        "job": "leader"
    }

    yield call(createUser,userData);

    let result = yield call(getAllUsers);

        yield put({
            type:reviewActions.REVIEW_SUBMIT_SUCCESS,
            payload:result.data.data
        })
}

export default function* root(){
    yield all([
        takeLatest(reviewActions.REVIEW_SUBMIT,reviewSubmit)
    ])
}