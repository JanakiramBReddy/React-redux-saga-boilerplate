import React from 'react';
import {TextField,Button, withStyles,FormControl} from '@material-ui/core';
import { connect } from 'react-redux';
import {reviewSubmit} from '../actions/reviewActions'; 

const style = theme => ({
    reviewBox:{
        alignItems: 'center',
        justifyContent: 'center',
        display: 'flex',
        height:'200px'
    },
    textFieldBox:{
        width:'800px'
    },
    submitReview:{
        alignItems: 'center',
        justifyContent: 'center',
        display:'flex'
    }
})

export class reviewContainer extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            reviewText : ''
        }
    }

    render(){
        const {classes} = this.props;
        return (
            <div>
                <div className={classes.reviewBox}>
                    <FormControl className={classes.textFieldBox}>
                        <TextField
                            id="outlined-multiline-static"
                            label="Review Box"
                            multiline
                            rows="4"
                            variant="outlined" 
                            InputProps = {{
                                inputProps : {
                                    maxLength : 200
                                }
                            }}
                            onChange={(e) => this.setState({reviewText:e.target.value})}
                        />
                    </FormControl>
                    <span style={{float:'right'}}>{this.state.reviewText.length}/150</span>
                </div>
                <div className={classes.submitReview}>
                <Button variant="contained" 
                onClick={() => { this.props.reviewSubmit({text:this.state.reviewText}) }}>submit</Button>
                </div>
            </div>
        )
    }
}

function mapStateToProps(state){
    return {
        reviewResult : state.review.value
    }
}

const mapDispatchToProps = dispatch => ({
    reviewSubmit : x => dispatch(reviewSubmit(x))
})

export default connect(mapStateToProps,mapDispatchToProps)(withStyles(style)(reviewContainer))