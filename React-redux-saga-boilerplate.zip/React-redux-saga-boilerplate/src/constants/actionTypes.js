import keyMirror from 'fbjs/lib/keyMirror';

export const reviewActions = keyMirror({
    REVIEW_SUBMIT : undefined,
    REVIEW_SUBMIT_SUCCESS : undefined
})